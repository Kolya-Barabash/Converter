var searchData=
[
  ['setdata',['setData',['../class_table_viewer.html#a86d279999fa3828496d93cb1f4f47353',1,'TableViewer::setData(QSqlDatabase &amp;db, QString table)'],['../class_table_viewer.html#aecf76861b778bccdd240970befdd6a28',1,'TableViewer::setData(QString name)']]]
];
