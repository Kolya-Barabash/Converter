var annotated_dup =
[
    [ "ConvertClass", "class_convert_class.html", "class_convert_class" ],
    [ "MainWindow", "class_main_window.html", "class_main_window" ],
    [ "TableViewer", "class_table_viewer.html", "class_table_viewer" ]
];