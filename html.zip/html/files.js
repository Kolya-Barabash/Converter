var files =
[
    [ "convertclass.cpp", "convertclass_8cpp_source.html", null ],
    [ "convertclass.h", "convertclass_8h.html", [
      [ "ConvertClass", "class_convert_class.html", "class_convert_class" ]
    ] ],
    [ "main.cpp", "main_8cpp_source.html", null ],
    [ "mainwindow.cpp", "mainwindow_8cpp_source.html", null ],
    [ "mainwindow.h", "mainwindow_8h.html", [
      [ "MainWindow", "class_main_window.html", "class_main_window" ]
    ] ],
    [ "processing.cpp", "processing_8cpp_source.html", null ],
    [ "processing.h", "processing_8h.html", "processing_8h" ],
    [ "tableviewer.cpp", "tableviewer_8cpp_source.html", null ],
    [ "tableviewer.h", "tableviewer_8h.html", [
      [ "TableViewer", "class_table_viewer.html", "class_table_viewer" ]
    ] ]
];