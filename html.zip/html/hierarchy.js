var hierarchy =
[
    [ "ConvertClass", "class_convert_class.html", null ],
    [ "QMainWindow", null, [
      [ "MainWindow", "class_main_window.html", null ]
    ] ],
    [ "TableViewer", "class_table_viewer.html", null ]
];