var class_table_viewer =
[
    [ "TableViewer", "class_table_viewer.html#ad85b119dc0c411b64abcfb9a9f07e407", null ],
    [ "returnModel", "class_table_viewer.html#ad8466d621363b97e9a3c8883976e90ab", null ],
    [ "setData", "class_table_viewer.html#a86d279999fa3828496d93cb1f4f47353", null ],
    [ "setData", "class_table_viewer.html#aecf76861b778bccdd240970befdd6a28", null ]
];