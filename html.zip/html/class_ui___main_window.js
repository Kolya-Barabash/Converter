var class_ui___main_window =
[
    [ "retranslateUi", "class_ui___main_window.html#a097dd160c3534a204904cb374412c618", null ],
    [ "setupUi", "class_ui___main_window.html#acf4a0872c4c77d8f43a2ec66ed849b58", null ],
    [ "actionClose", "class_ui___main_window.html#a470280f75a14499f32a8b707ea9a6435", null ],
    [ "actionOpencsv", "class_ui___main_window.html#ade80d332864539dfb4426063463080f0", null ],
    [ "actionOpenDb", "class_ui___main_window.html#a306d10de68c830c28a9dc3295a8dac10", null ],
    [ "centralWidget", "class_ui___main_window.html#a30075506c2116c3ed4ff25e07ae75f81", null ],
    [ "convertButton", "class_ui___main_window.html#ada1d197ffc4bda4d7d4265f4b48911c0", null ],
    [ "convertSqlButton", "class_ui___main_window.html#aa1472d5efb82420fbb147ecc2564e395", null ],
    [ "gridLayout", "class_ui___main_window.html#a525ed3c5fe0784ac502ee222fba4e205", null ],
    [ "mainToolBar", "class_ui___main_window.html#a5172877001c8c7b4e0f6de50421867d1", null ],
    [ "menu", "class_ui___main_window.html#abe2eb1a23c01639b2a6ba0e562c28c4d", null ],
    [ "menuBar", "class_ui___main_window.html#a2be1c24ec9adfca18e1dcc951931457f", null ],
    [ "showButton", "class_ui___main_window.html#aa07dfaff78621226955d0aaa005108a5", null ],
    [ "sqlView", "class_ui___main_window.html#a358e0c8ac4fa69905b47784d97da07e3", null ],
    [ "statusBar", "class_ui___main_window.html#a50fa481337604bcc8bf68de18ab16ecd", null ],
    [ "tableBox", "class_ui___main_window.html#ad1a0af97aeb8d5f455473bc1e7ea7b61", null ]
];