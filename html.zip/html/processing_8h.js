var processing_8h =
[
    [ "parseStr", "processing_8h.html#aebed2b84c947f80a7ef6286e8200a4b5", null ],
    [ "processingForCsvStr", "processing_8h.html#a409a5394ea1edfd9cd72ffe15988efad", null ],
    [ "whatType", "processing_8h.html#a643d2e2bcb1fe9ffd471ced79dbe008c", null ],
    [ "withoutQuotes", "processing_8h.html#a78fdc7e0162fc38ca1a07890a59c9298", null ]
];